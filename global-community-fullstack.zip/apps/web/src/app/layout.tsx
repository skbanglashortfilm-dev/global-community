import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'Global Community', description: 'Connect the World. Share Everything.' };
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return <html lang="en"><body>{children}</body></html>;
}
